package com.clide.fighter;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.graphics.*;
import android.content.Context;
import android.os.Handler;
import java.util.Random;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
        setContentView(new FightView(this));
    }

    static class FightView extends View {
        Paint p = new Paint(3);
        Handler handler = new Handler();
        float playerHp=1f, enemyHp=1f, playerX=.28f, enemyX=.72f;
        int playerAction=0, enemyAction=0, frame=0, round=1;
        int selected=0, enemyCharacter=1;
        long actionUntil=0, enemyHitAt=0;
        boolean blocking=false, over=false, won=false, choosing=true;
        String message="FIGHT!";
        Random random=new Random();
        float W,H;
        String[] names={"BLUE NINJA","FIRE FIGHTER","SHADOW FIGHTER","GOLDEN CHAMPION"};
        int[] colors={Color.rgb(40,190,255),Color.rgb(255,85,65),Color.rgb(80,220,130),Color.rgb(255,195,45)};
        FightView(Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); handler.post(tick); }
        Runnable tick=new Runnable(){ public void run(){ update(); invalidate(); handler.postDelayed(this,45); }};
        void update(){
            frame++;
            long now=System.currentTimeMillis();
            if(playerAction!=0 && now>actionUntil) playerAction=0;
            if(!choosing && !over && now-enemyHitAt>1050 && random.nextInt(28)==0){
                enemyAction=1; enemyHitAt=now;
                if(Math.abs(enemyX-playerX)<.48f && !blocking) playerHp=Math.max(0,playerHp-.07f);
            }
            if(playerHp<=0 || enemyHp<=0){ over=true; won=enemyHp<=0; message=won?"YOU WIN!":"YOU LOSE!"; }
        }
        void text(Canvas c,String s,float x,float y,float size,int color){
            p.setColor(color); p.setTextSize(size); p.setTypeface(Typeface.create("sans-serif-black",Typeface.BOLD)); c.drawText(s,x,y,p);
        }
        void background(Canvas c){
            c.drawColor(Color.rgb(18,22,42));
            p.setShader(new LinearGradient(0,H*.45f,0,H,Color.rgb(60,70,112),Color.rgb(20,25,48),Shader.TileMode.CLAMP));
            c.drawRect(0,H*.42f,W,H,p); p.setShader(null);
            p.setColor(Color.rgb(255,184,60)); c.drawRect(0,H*.415f,W,H*.43f,p);
            for(int i=0;i<8;i++){ p.setColor(Color.argb(80,80,180,255)); c.drawCircle(i*W/7f,H*.2f,18,p); }
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); W=getWidth(); H=getHeight();
            background(c);
            if(choosing){ drawSelect(c); return; }
            text(c,"CLIDE FIGHTER",W*.40f,H*.10f,H*.055f,Color.WHITE);
            text(c,"OWNER: CLIDE TABASON",18,H*.09f,H*.035f,Color.rgb(255,210,80));
            p.setColor(Color.DKGRAY); c.drawRoundRect(W*.06f,H*.15f,W*.43f,H*.205f,12,12,p);
            c.drawRoundRect(W*.57f,H*.15f,W*.94f,H*.205f,12,12,p);
            p.setColor(Color.rgb(60,220,100)); c.drawRoundRect(W*.06f,H*.15f,W*(.06f+.37f*playerHp),H*.205f,12,12,p);
            p.setColor(Color.rgb(245,70,75)); c.drawRoundRect(W*.57f,H*.15f,W*(.57f+.37f*enemyHp),H*.205f,12,12,p);
            text(c,"YOU",W*.06f,H*.14f,H*.035f,Color.WHITE); text(c,"CPU",W*.88f,H*.14f,H*.035f,Color.WHITE);
            fighter(c,playerX*W,H*.70f,true,playerAction,colors[selected],selected);
            fighter(c,enemyX*W,H*.70f,false,enemyAction,colors[enemyCharacter],enemyCharacter);
            text(c,"ROUND  "+round,W*.45f,H*.29f,H*.04f,Color.WHITE);
            button(c,"MOVE",W*.02f,H*.82f,W*.20f,H*.96f,Color.rgb(110,95,210));
            button(c,"PUNCH",W*.55f,H*.82f,W*.69f,H*.96f,Color.rgb(40,135,240));
            button(c,"KICK",W*.72f,H*.82f,W*.86f,H*.96f,Color.rgb(240,135,35));
            button(c,"BLOCK",W*.89f,H*.82f,W*.99f,H*.96f,Color.rgb(70,170,100));
            if(over){
                p.setColor(0xCC000000); c.drawRect(0,0,W,H,p);
                text(c,message,W*.38f,H*.48f,H*.10f,won?Color.GREEN:Color.RED);
                text(c,"TAP ANYWHERE TO PLAY AGAIN",W*.31f,H*.60f,H*.04f,Color.WHITE);
            }
        }
        void drawSelect(Canvas c){
            text(c,"CLIDE FIGHTER",W*.36f,H*.12f,H*.075f,Color.WHITE);
            text(c,"OWNER: CLIDE TABASON",W*.02f,H*.10f,H*.032f,Color.rgb(255,210,80));
            text(c,"CHOOSE YOUR FIGHTER",W*.36f,H*.23f,H*.045f,Color.WHITE);
            float gap=W*.018f, cardW=W*.22f, top=H*.31f, bottom=H*.78f;
            for(int i=0;i<4;i++){
                float left=W*.025f+i*(cardW+gap), right=left+cardW;
                p.setColor(i==selected?Color.rgb(255,195,45):Color.rgb(75,82,115));
                c.drawRoundRect(left,top,right,bottom,18,18,p);
                fighter(c,(left+right)/2,H*.57f,true,0,colors[i],i);
                text(c,names[i],left+10,H*.72f,H*.027f,Color.WHITE);
                if(i==selected) text(c,"SELECTED",left+10,H*.77f,H*.023f,Color.YELLOW);
            }
            button(c,"START FIGHT",W*.39f,H*.83f,W*.61f,H*.97f,Color.rgb(40,180,90));
        }
        void button(Canvas c,String s,float l,float t,float r,float b,int color){
            p.setColor(color); c.drawRoundRect(l,t,r,b,18,18,p);
            text(c,s,l+12,(t+b)/2+10,H*.032f,Color.WHITE);
        }
        void fighter(Canvas c,float x,float y,boolean left,int action,int color,int type){
            c.save(); c.translate(x,y); if(!left)c.scale(-1,1);
            p.setColor(Color.argb(65,0,0,0)); c.drawOval(-42,48,42,65,p);
            p.setColor(color); c.drawRoundRect(-23,-12,23,50,12,12,p);
            p.setColor(Color.rgb(235,190,150)); c.drawCircle(0,-35,22,p);
            p.setColor(type==2?Color.BLACK:Color.rgb(35,30,40));
            c.drawArc(-22,-57,22,-18,180,180,false,p);
            p.setStrokeWidth(13); p.setStrokeCap(Paint.Cap.ROUND); p.setColor(color);
            if(action==1){ c.drawLine(12,0,65,-18,p); c.drawLine(-12,0,-28,25,p); }
            else if(action==2){ c.drawLine(10,5,55,35,p); c.drawLine(-10,5,-28,25,p); }
            else { c.drawLine(15,0,38,22,p); c.drawLine(-15,0,-38,22,p); }
            c.drawLine(-12,40,-20,62,p); c.drawLine(12,40,22,62,p);
            if(type==3){ p.setColor(Color.YELLOW); c.drawCircle(0,-61,7,p); }
            c.restore();
        }
        void attack(boolean kick){
            if(over)return;
            playerAction=kick?2:1; actionUntil=System.currentTimeMillis()+260;
            if(Math.abs(enemyX-playerX)<.48f){
                enemyHp=Math.max(0,enemyHp-(kick?.13f:.09f));
                enemyAction=kick?2:1;
            }
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_DOWN)return true;
            float x=e.getX(), y=e.getY();
            if(choosing){
                if(y>H*.82f){ choosing=false; enemyCharacter=(selected+1+random.nextInt(3))%4; return true; }
                if(y>H*.28f && y<H*.81f){
                    int idx=(int)(x/(W/4f)); selected=Math.max(0,Math.min(3,idx));
                }
                return true;
            }
            if(over){ playerHp=enemyHp=1f; over=false; choosing=true; playerX=.28f; enemyX=.72f; return true; }
            if(y>H*.80f){
                if(x>W*.88f) blocking=true;
                else if(x>W*.70f) attack(true);
                else if(x>W*.53f) attack(false);
                else playerX=Math.min(.47f,playerX+.06f);
            } else if(x<W*.5f){ playerX=Math.max(.12f,playerX-.06f); }
            return true;
        }
    }
}
